import gremlin from 'gremlin';
const DriverRemoteConnection = gremlin.driver.DriverRemoteConnection;
const Graph = gremlin.structure.Graph;
const traversal = gremlin.process.AnonymousTraversalSource.traversal;
const __ = gremlin.process.statics;
const p = gremlin.process.P;
const textp = gremlin.process.TextP;
const pick = gremlin.process.pick;
const pop = gremlin.process.pop;
const order = gremlin.process.order;
const scope = gremlin.process.scope;
const { t, gt } = gremlin.process;


const neptuneEndpoint = 'wss://cs4440-database.cluster-c4waquyvhdu3.us-east-1.neptune.amazonaws.com:8182/gremlin';


export const handler = async (event, context) => {
  //const dc = new DriverRemoteConnection(neptuneEndpoint, {});
  const dc = new DriverRemoteConnection(neptuneEndpoint,
  { mimeType: "application/vnd.gremlin-v2.0+json" } // Fall back to GraphSON v2
  );
  const graph = new Graph();
  const g = graph.traversal().withRemote(dc);
  

  try {
    // console.log('Event:', JSON.stringify(event));
    // API Gateway passes arguments into event object as key-value pair
    // console.log(event.body);
    
    // Use the values to test the post request 
    
    const body = JSON.parse(event.body);
    const symptomsList = body['symptoms'];
    const gender = body['gender'];
    
    // console.log(symptomsList);
    // console.log(gender);
    
    /*
    return {
      statusCode: 200,
      body: JSON.stringify(res),
    };
    */
    
    // Use these for local test on lambda function
    // const symptomsList = ["headache"];
    // const gender = 'male';
    
    const data = await g.V().hasLabel('symptom').has('name', p.within(...symptomsList)).outE('hasCondition').has(gender, p.neq(null)).group().by(__.inV()).by(__.values(gender).sum()).toList();
    const sortedArray = Object.entries(data['0']).sort((a, b) => b[1] - a[1]);    
    const topConditions = sortedArray.slice(0, 3);
    const topConditionsID = [];
    topConditions.forEach((element) => {
      topConditionsID.push(element[0]);
    });
    
    // console.log(top5ConditionsID);
    const res = await g.V().hasId(p.within(...topConditionsID)).elementMap().toList();
    // console.log(typeof(res));
    // console.log(Object.keys(res));
    
    const output = [];
    var name = "";
    for (const prop in res) {
      name = res[prop].name;
      const temp = {
        name: name,
        treatments: []
      }
      const treatments = await g.V().has('name', p.within(name)).outE('hasTreatment').has(gender, p.neq(null)).group().by(__.inV()).by(__.values(gender).sum()).toList();
      const sortedTreatments = Object.entries(treatments['0']).sort((a, b) => b[1] - a[1]);
      const top3Treatments = sortedTreatments.slice(0, 3);
      const top3TreatmentsID = [];
      top3Treatments.forEach((element) => {
      top3TreatmentsID.push(element[0]);
      });
      const resTreatment = await g.V().hasId(p.within(...top3TreatmentsID)).elementMap().toList();
      for (const prop in resTreatment) {
        name = resTreatment[prop].name;
        var dosage = resTreatment[prop].dosage;
        const treatmentObj = {
          name: name,
          dosage: dosage,
        }
        temp.treatments.push(treatmentObj);
      }
      output.push(temp);
    }
    
    
    // console.log(resTreatment);

    // Close the connection
    console.log('Closing connection');
    await dc.close();
    // console.log(queriesNoOrder['1423']);
    // console.log(queryUnordered);

    // Return the result
    //TODO return the result to application here
    return {
      statusCode: 200,
      body: JSON.stringify(output),
    };
  } catch (error) {
    console.error('Error executing query:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Error executing query' }),
    };
  }
};